import React, { useState }  from 'react';
import './App.css';
import HalfDoughnutGaugeChart from './HalfDoughnutGaugeChart';
import DoughnutChart1 from './DoughnutChart1';
import DoughnutChart2 from './DoughnutChart2';
import DoughnutChart3 from './doughnutChart3';


const App = () => {
  const [value, setValue] = useState(6.4);
  const [inputValue, setInputValue] = useState('');

  const handleChange = (event) => {
    setInputValue(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!isNaN(inputValue)) {
      setValue(Number(inputValue));
    }
    setInputValue('');
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1 style={{marginTop:"6rem", fontSize: "3rem"}}>Doughnut chart example</h1>
      </header>
      <div className="chart-container">
      <HalfDoughnutGaugeChart dataValues={[40,60]}/><br></br>
      
    
      
        <div style={{display: "flex",marginTop : "10rem"}}> 
       <DoughnutChart1 />
        <DoughnutChart2 />
        <DoughnutChart3 />
        </div>
      </div>
    </div>
  );
}

export default App;

