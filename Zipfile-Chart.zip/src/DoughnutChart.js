import React, { useEffect, useRef } from 'react';
import Chart from 'chart.js';

const DoughnutChart = ({ data }) => {
  const chartRef = useRef(null);

  useEffect(() => {
    const config = {
      type: 'doughnut',
      data: data,
      options: {
        aspectRatio: 2,
        rotation: 290,
        cutoutPercentage: 90,
        plugins: {
          legend: {
            display: false
          }
        }
      }
    };

    const myChart = new Chart(chartRef.current, config);

    return () => {
      myChart.destroy();
    };
  }, [data]);

    
  return <canvas ref={chartRef} style={{marginLeft: "-15rem"}}/>;
};

export default DoughnutChart;
