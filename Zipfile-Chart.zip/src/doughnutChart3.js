import React from 'react';
import DoughnutChart from './DoughnutChart';

const data = {
  labels: ['Label 1', 'Label 2'],
  datasets: [{
    label: 'Dataset 3',
    data: [50, 50],
    backgroundColor: [
        'rgb(5, 215, 124)',
        'rgba(0, 0, 0, 0.2)'
      ],
      borderColor: [
        'rgb(5, 215, 124)',
        'rgba(0, 0, 0, 0.2)'
      ],
    borderWidth: [7,0]
  }]
};

const DoughnutChart3 = () => {
  return <DoughnutChart data={data} />;
};

export default DoughnutChart3;
