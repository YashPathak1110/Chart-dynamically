import React from 'react';
import DoughnutChart from './DoughnutChart';

const data = {
  labels: ['Label 1', 'Label 2'],
  datasets: [{
    label: 'Dataset 1',
    data: [40, 60],
    backgroundColor: [
      'rgb(92, 27, 153)',
      'rgba(0, 0, 0, 0.3)'
    ],
    borderColor: [
      'rgb(92, 27, 153)',
      'rgba(0, 0, 0, 1)'
    ],
    borderWidth: [7, 0],
  }]
};

const DoughnutChart1 = () => {
  
      return <DoughnutChart data={data} />;
     

};

export default DoughnutChart1;