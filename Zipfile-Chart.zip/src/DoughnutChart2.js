import React from 'react';
import DoughnutChart from './DoughnutChart';

const data = {
  labels: ['Label 1', 'Label 2'],
  datasets: [{
    label: 'Dataset 2',
    data: [80, 20],
    backgroundColor: [
      'rgb(236, 71, 11)',
      'rgba(0, 0, 0, 0.3)'
    ],
    borderColor: [
      'rgb(236, 71, 11)',
      'rgba(0, 0, 0, 0.3)'
    ],
    borderWidth: [7,0]
  }]
};

const DoughnutChart2 = () => {
  return <DoughnutChart data={data} />;
};

export default DoughnutChart2;
